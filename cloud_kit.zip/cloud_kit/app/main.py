
import os
import math
import yaml
import smtplib
import pandas as pd
import numpy as np
import yfinance as yf
from datetime import datetime, timedelta
from pathlib import Path
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate
from email import encoders

# Optional: statsmodels for OLS
try:
    import statsmodels.api as sm
except Exception:
    sm = None

# Optional: ReportLab for PDF
try:
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import cm
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle
    from reportlab.lib import colors
except Exception:
    pass  # We'll handle missing reportlab gracefully

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"
OUT.mkdir(exist_ok=True, parents=True)

def zscore(series):
    return (series - series.mean()) / series.std(ddof=0)

def load_config(path="config.yaml"):
    with open(ROOT / path, "r") as f:
        return yaml.safe_load(f)

def download_series(tickers, start, end):
    df = yf.download(list(tickers), start=start, end=end, auto_adjust=True, progress=False, group_by='ticker')
    return df

def get_close(df, ticker):
    if ticker not in df:
        return None
    return df[ticker]["Close"].dropna().rename(ticker)

def estimate_ttm_yield(ticker, last_price):
    ttm = None
    try:
        tk = yf.Ticker(ticker)
        info = tk.info or {}
        if "dividendYield" in info and info["dividendYield"]:
            ttm = 100.0 * info["dividendYield"]
        # backup via 365d dividend sum
        divs = tk.dividends
        if len(divs) > 0 and last_price and last_price > 0:
            last_365 = divs[divs.index >= divs.index.max() - pd.Timedelta(days=365)].sum()
            ttm2 = 100.0 * (last_365 / last_price)
            ttm = max(ttm or 0.0, ttm2)
    except Exception:
        pass
    return ttm

def run_scan(config):
    start_years = config.get("history_years", 10)
    end = datetime.today()
    start = end - timedelta(days=365*start_years + 30)

    lookback_corr = config.get("lookback_corr_days", 90)
    lookback_beta = config.get("lookback_beta_days", 180)
    dislocation_z = config.get("dislocation_z_threshold", 2.0)
    corr_break_delta = config.get("corr_break_delta", 0.4)

    companies = config["companies"]
    commodities = config["commodities"]

    all_tickers = set([c["ticker"] for c in companies]) | set([com["ticker"] for com in commodities])
    data = download_series(all_tickers, start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d"))

    rows = []
    for comp in companies:
        ctick = comp["ticker"]
        cname = comp.get("name", ctick)
        linked = comp.get("linked_commodities", [])

        cpx = get_close(data, ctick)
        if cpx is None:
            continue

        ttm_yield = estimate_ttm_yield(ctick, cpx.iloc[-1] if len(cpx) else None)

        for l in linked:
            proxy = next((com["ticker"] for com in commodities if com["key"] == l), None)
            if proxy is None:
                continue
            px = get_close(data, proxy)
            if px is None:
                continue

            df = pd.concat([cpx, px], axis=1).dropna()
            if len(df) < max(lookback_beta, lookback_corr) + 50:
                continue

            corr = df[ctick].pct_change().rolling(lookback_corr).corr(df[proxy].pct_change())
            current_corr = corr.iloc[-1]
            baseline_corr = corr.dropna().tail(252).mean()
            corr_drop = (baseline_corr - current_corr) if pd.notna(current_corr) and pd.notna(baseline_corr) else np.nan

            beta = np.nan
            resid_z = np.nan
            if sm is not None:
                win = df.dropna().tail(lookback_beta)
                y = win[ctick].pct_change().dropna()
                x = win[proxy].pct_change().dropna()
                j = pd.concat([y, x], axis=1).dropna()
                if len(j) > 30:
                    X = sm.add_constant(j[proxy])
                    model = sm.OLS(j[ctick], X).fit()
                    beta = model.params.get(proxy, np.nan)
                    aligned = j.copy()
                    aligned["pred"] = model.predict(sm.add_constant(aligned[proxy]))
                    aligned["res"] = aligned[ctick] - aligned["pred"]
                    resid_z = zscore(aligned["res"]).iloc[-1]

            disloc = abs(resid_z) >= dislocation_z if not math.isnan(resid_z) else False
            corr_break = (not math.isnan(corr_drop)) and (corr_drop >= corr_break_delta)

            rows.append({
                "company": cname,
                "ticker": ctick,
                "commodity_key": l,
                "commodity_ticker": proxy,
                "date": df.index[-1].date(),
                "price": round(float(cpx.iloc[-1]), 4),
                "commodity_price": round(float(px.iloc[-1]), 4),
                "corr_lookback": round(float(current_corr), 3) if pd.notna(current_corr) else np.nan,
                "corr_baseline_1y": round(float(baseline_corr), 3) if pd.notna(baseline_corr) else np.nan,
                "corr_drop": round(float(corr_drop), 3) if pd.notna(corr_drop) else np.nan,
                "beta": round(float(beta), 3) if not math.isnan(beta) else np.nan,
                "residual_z": round(float(resid_z), 3) if not math.isnan(resid_z) else np.nan,
                "dislocation_flag": bool(disloc),
                "corr_break_flag": bool(corr_break),
                "ttm_yield_pct": round(float(ttm_yield), 2) if ttm_yield is not None else np.nan
            })

    report = pd.DataFrame(rows).sort_values(
        by=["dislocation_flag", "corr_break_flag", "ttm_yield_pct"],
        ascending=[False, False, True]
    )
    ts = datetime.now().strftime("%Y%m%d_%H%M")
    out_csv = OUT / f"scan_{ts}.csv"
    report.to_csv(out_csv, index=False)
    return report, out_csv

def run_backtest(config):
    # Simple backtest:
    # Rule: enter long when |z|>=2 OR corr_drop>=0.4; exit when z crosses 0 (sign change) or after 60 trading days (timeout).
    start_years = config.get("history_years", 10)
    end = datetime.today()
    start = end - timedelta(days=365*start_years + 30)

    lookback_corr = config.get("lookback_corr_days", 90)
    lookback_beta = config.get("lookback_beta_days", 180)
    dislocation_z = config.get("dislocation_z_threshold", 2.0)
    corr_break_delta = config.get("corr_break_delta", 0.4)
    max_hold_days = 60

    companies = config["companies"]
    commodities = config["commodities"]
    all_tickers = set([c["ticker"] for c in companies]) | set([com["ticker"] for com in commodities])
    data = download_series(all_tickers, start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d"))

    results = []
    for comp in companies:
        ctick = comp["ticker"]
        linked = comp.get("linked_commodities", [])
        cpx = get_close(data, ctick)
        if cpx is None:
            continue

        for l in linked:
            proxy = next((com["ticker"] for com in commodities if com["key"] == l), None)
            if proxy is None: 
                continue
            px = get_close(data, proxy)
            if px is None:
                continue

            df = pd.concat([cpx, px], axis=1).dropna()
            if len(df) < max(lookback_beta, lookback_corr) + 120:
                continue

            # Build daily z and corr_drop series
            rets_c = df[ctick].pct_change()
            rets_p = df[proxy].pct_change()

            # Rolling corr
            corr_series = rets_c.rolling(lookback_corr).corr(rets_p)
            baseline_roll = corr_series.rolling(252).mean()
            corr_drop_series = baseline_roll - corr_series

            # Rolling beta & residual z
            z_series = pd.Series(index=df.index, dtype=float)
            if sm is not None:
                for idx in range(len(df)):
                    if idx < lookback_beta:
                        continue
                    window = df.iloc[idx-lookback_beta+1:idx+1]
                    y = window[ctick].pct_change().dropna()
                    x = window[proxy].pct_change().dropna()
                    j = pd.concat([y, x], axis=1).dropna()
                    if len(j) < 30:
                        continue
                    X = sm.add_constant(j[proxy])
                    model = sm.OLS(j[ctick], X).fit()
                    pred = model.predict(sm.add_constant(j[proxy]))
                    res = j[ctick] - pred
                    z_series.iloc[idx] = ((res - res.mean())/res.std(ddof=0)).iloc[-1] if res.std(ddof=0) else np.nan

            # Simulate trades
            in_trade = False
            entry_price = None
            entry_date = None
            pnl = []
            trades = []

            for i, dt in enumerate(df.index):
                price = df.loc[dt, ctick]
                z = z_series.get(dt, np.nan)
                cd = corr_drop_series.get(dt, np.nan)

                if not in_trade:
                    if (pd.notna(z) and abs(z) >= dislocation_z) or (pd.notna(cd) and cd >= corr_break_delta):
                        in_trade = True
                        entry_price = price
                        entry_date = dt
                else:
                    # exit condition
                    days_held = (dt - entry_date).days
                    z_ok = pd.notna(z) and (abs(z) < 0.3)  # close to neutral
                    timeout = days_held >= max_hold_days
                    if z_ok or timeout:
                        ret = (price / entry_price) - 1.0
                        trades.append((entry_date.date(), dt.date(), float(ret)))
                        in_trade = False
                        entry_price = None
                        entry_date = None

                # mark-to-market PnL (not strictly needed)
                if in_trade and entry_price:
                    pnl.append((dt, float(price/entry_price - 1.0)))

            # Summarize
            if trades:
                rets = pd.Series([t[2] for t in trades])
                summary = {
                    "ticker": ctick,
                    "proxy": proxy,
                    "n_trades": len(trades),
                    "win_rate_%": round(100.0 * (rets > 0).mean(), 1),
                    "avg_trade_%": round(100.0 * rets.mean(), 2),
                    "median_trade_%": round(100.0 * rets.median(), 2),
                    "sum_%": round(100.0 * rets.sum(), 2),
                }
                results.append(summary)

    bt = pd.DataFrame(results).sort_values(by=["sum_%", "win_rate_%"], ascending=[False, False])
    ts = datetime.now().strftime("%Y%m%d_%H%M")
    out_csv = OUT / f"backtest_{ts}.csv"
    bt.to_csv(out_csv, index=False)
    return bt, out_csv

def make_pdf(report_df, backtest_df, out_path):
    try:
        doc = SimpleDocTemplate(str(out_path), pagesize=A4, rightMargin=36, leftMargin=36, topMargin=36, bottomMargin=36)
        story = []
        styles = getSampleStyleSheet()
        title = Paragraph("<b>Royalties & Commodities — Rapport quotidien</b>", styles["Title"])
        story.append(title)
        story.append(Spacer(1, 12))

        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        story.append(Paragraph(f"Généré: {now}", styles["Normal"]))
        story.append(Spacer(1, 12))

        story.append(Paragraph("<b>Top signaux (Top-10)</b>", styles["Heading2"]))
        top = report_df.head(10).copy()
        cols = ["ticker","commodity_ticker","residual_z","corr_lookback","corr_drop","beta","price","ttm_yield_pct"]
        top = top[cols]
        data = [ [c.replace("_"," ").title() for c in cols] ] + top.values.tolist()
        table = Table(data, repeatRows=1)
        table.setStyle(TableStyle([
            ('BACKGROUND',(0,0),(-1,0), colors.grey),
            ('TEXTCOLOR',(0,0),(-1,0), colors.white),
            ('GRID',(0,0),(-1,-1), 0.25, colors.black),
            ('ALIGN',(2,1),(-1,-1),'RIGHT')
        ]))
        story.append(table)
        story.append(Spacer(1, 18))

        story.append(Paragraph("<b>Backtest (résumé)</b>", styles["Heading2"]))
        if backtest_df is not None and len(backtest_df):
            cols2 = ["ticker","proxy","n_trades","win_rate_%","avg_trade_%","median_trade_%","sum_%"]
            bt = backtest_df[cols2]
            data2 = [cols2] + bt.values.tolist()
            table2 = Table(data2, repeatRows=1)
            table2.setStyle(TableStyle([
                ('BACKGROUND',(0,0),(-1,0), colors.grey),
                ('TEXTCOLOR',(0,0),(-1,0), colors.white),
                ('GRID',(0,0),(-1,-1), 0.25, colors.black),
                ('ALIGN',(2,1),(-1,-1),'RIGHT')
            ]))
            story.append(table2)
        else:
            story.append(Paragraph("Pas de résultats backtest disponibles.", styles["Italic"]))

        doc.build(story)
        return True
    except Exception as e:
        print("PDF error:", e)
        return False

def send_email_with_attachment(smtp_host, smtp_port, smtp_user, smtp_password, to_email, subject, body, file_path):
    msg = MIMEMultipart()
    msg['From'] = smtp_user
    msg['To'] = to_email
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    with open(file_path, "rb") as f:
        part = MIMEBase('application', "octet-stream")
        part.set_payload(f.read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', f'attachment; filename="{Path(file_path).name}"')
    msg.attach(part)

    with smtplib.SMTP_SSL(smtp_host, smtp_port) as server:
        server.login(smtp_user, smtp_password)
        server.sendmail(smtp_user, [to_email], msg.as_string())

def run_all():
    cfg = load_config("config.yaml")
    report_df, scan_csv = run_scan(cfg)
    bt_df, bt_csv = run_backtest(cfg)

    ts = datetime.now().strftime("%Y%m%d_%H%M")
    pdf_path = OUT / f"report_{ts}.pdf"
    ok_pdf = make_pdf(report_df, bt_df, pdf_path)

    # Email if env vars present
    smtp_host = os.getenv("SMTP_HOST")
    smtp_port = int(os.getenv("SMTP_PORT", "465"))
    smtp_user = os.getenv("SMTP_USER")
    smtp_password = os.getenv("SMTP_PASSWORD")
    to_email = os.getenv("TO_EMAIL")

    if smtp_host and smtp_user and smtp_password and to_email and ok_pdf:
        send_email_with_attachment(
            smtp_host, smtp_port, smtp_user, smtp_password, to_email,
            subject="Royalties Screener - Rapport quotidien",
            body="Voici le rapport quotidien (Top-10 + Backtest résumé).",
            file_path=str(pdf_path)
        )
        print("Email envoyé.")
    else:
        print("Email non envoyé (variables SMTP manquantes)")
    print("Terminé.")

if __name__ == "__main__":
    run_all()
